"Operacyjne"
import numpy as np
import warnings
import joblib
from IPython.display import display, clear_output
from collections import Counter
import time
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
"Balansowanie"
from imblearn.metrics import classification_report_imbalanced
from imblearn.pipeline import make_pipeline
from imblearn.under_sampling import NearMiss
"Sklearn operacyjne"
from sklearn import model_selection
from sklearn.model_selection import cross_validate, train_test_split, cross_val_predict
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, label_binarize, MinMaxScaler
from sklearn.metrics import confusion_matrix, precision_recall_curve, roc_curve, auc
import sklearn.metrics
from sklearn.inspection import permutation_importance
"Sklearn modle"
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
"Sklearn Stacking"
from sklearn.ensemble import StackingClassifier
"Imblearn - balasowanie"
from imblearn.under_sampling import ClusterCentroids, RandomUnderSampler, NearMiss, EditedNearestNeighbours, RepeatedEditedNearestNeighbours, TomekLinks

df8 = pd.read_csv('DaneModelTMP.csv', delimiter=',')
df4 = pd.read_csv('DaneModelTMP_4klasy.csv', delimiter=';')

nazwa_kolumn = ['Pora','Zachm6', 'ZachmN6', 'Wiatr_N', 'Wiatr_E', 'Wiatr_S', \
'Wiatr_W', 'TemperaturaPowietrza', 'DeltaTemp6','DeltaTempRosy6', 'TemperaturaPunktuRosy', \
'Cisn6', 'CisnienieNaPoziomieStacji', 'Opady6', \
'Mgla6', 'Mzawka6', 'Deszcz6', 'Snieg6', 'Przelotny6', 'Burza6', \
'Mgla_W', 'Mgla_E', 'Mgla_N', 'Mgla_S', 'Mzawka_W', 'Mzawka_E', \
'Mzawka_N', 'Mzawka_S', 'Burza_W', 'Burza_E', 'Burza_N', 'Burza_S', \
'Deszcz_W', 'Deszcz_E', 'Deszcz_N', 'Deszcz_S', 'Snieg_W', \
'Snieg_E', 'Snieg_N', 'Snieg_S', 'OpadM_W', 'OpadM_E', 'OpadM_N', \
'OpadM_S', 'Przelotny_W', 'Przelotny_E', 'Przelotny_N', \
'Przelotny_S']
y8 = []
X8, y8 = df8[nazwa_kolumn], df8.Pred6
y4 = []
X4, y4 = df4[nazwa_kolumn], df4.Pred6

scaler8 = StandardScaler()
scaler4 = StandardScaler()
scaler8.fit(X8)
scaler4.fit(X4)
X8_scaled = scaler8.transform(X8)
X4_scaled = scaler4.transform(X4)

scaler8 = MinMaxScaler()
scaler4 = MinMaxScaler()
X8_norm = scaler8.fit_transform(X8)
X4_norm = scaler4.fit_transform(X4)

podzial = model_selection.KFold(n_splits=5, shuffle=True, random_state=125)
podzial_Stratified = model_selection.StratifiedKFold(n_splits=5, shuffle=True, random_state=125)
X8_train, X8_test, y8_train, y8_test = train_test_split(X8, y8, test_size=0.2, random_state=42)
X4_train, X4_test, y4_train, y4_test = train_test_split(X4, y4, test_size=0.2, random_state=42)

miary=['accuracy', 'balanced_accuracy', 'r2', 'roc_auc_ovo', 'roc_auc_ovr_weighted', 'roc_auc_ovo_weighted','precision','recall', 'f1_micro', 'f1_macro']

"Clasifikatory oparte na drzewach"
dtreec = DecisionTreeClassifier()
rfc = RandomForestClassifier()
adac = AdaBoostClassifier()

"Cladyfikatory oparte na rozkłądzie"
gnbc = GaussianNB()
#gbc = GradientBoostingClassifier()

"Models" #Zastanów się co je łączy
knc = KNeighborsClassifier(n_neighbors=2)
lrc = LogisticRegression()
#svc = SVC(probability=True)
#lsvc = LinearSVC(probability=True)

lista_modeli = [
    ('dtreec', dtreec), # - sprawdzone działa
    ('rfc', rfc), # - sprawdzone działa
    ('adac', adac),# - sprawdzone działa
    ('gnbc', gnbc),# - sprawdzone działa
   # ('gbc', gbc), #- sprawdzone działa 26 min
    ('knc', knc), #- sprawdzone działa 1 min
    ('lrc', lrc), #- działa 1min (woring dotyczy nie podania mokasymalnej ilości iteracji (która standardowo wynosi 100))
   # ('svc', svc), #- nie przetestowane bardzo długo to działa (nie obsuguje prawdopodobieństw dodanie probability=True poprawio pomóc)
    #('lsvc', lsvc), #- nie przetestowane bardzo długo to działa (nie obsuguje prawdopodobieństw dodanie probability=True poprawio pomóc)
]


# FUNKCJE
def pca(X, y, title, ax_pca, ax_comp, ax_cumulative, n_components):
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X_scaled)
    colors = ['navy', 'turquoise', 'darkorange', 'red', 'green', 'blue', 'purple']
    markersize = 5

    # Wykres PCA
    for color, i in zip(colors, np.unique(y)):
        ax_pca.scatter(X_pca[y == i, 0], X_pca[y == i, 1], alpha=.8, color=color, s=markersize, label=i)
    ax_pca.set_title(title)
    ax_pca.legend(loc='best', shadow=False, scatterpoints=1, fontsize='small')

    # Wykres składowych
    components = pca.explained_variance_ratio_
    ax_comp.bar(range(1, len(components) + 1), components, alpha=0.5, label='Indywidualna wariancja')
    ax_comp.set_xlabel('Składowe główne (PC)')
    ax_comp.set_ylabel('Wyjaśniona wariancja')
    ax_comp.set_title(f'Indywidualna wariancja dla {title}')
    ax_comp.legend()

    # Wykres skumulowanej wariancji
    cumulative_components = np.cumsum(components)
    ax_cumulative.plot(range(1, len(cumulative_components) + 1), cumulative_components, marker='o', label='Kumulatywna wariancja')
    ax_cumulative.set_xlabel('Składowe główne (PC)')
    ax_cumulative.set_ylabel('Kumulatywna wyjaśniona wariancja')
    ax_cumulative.set_title(f'Kumulatywna wariancja dla {title}')
    ax_cumulative.grid(True)
    ax_cumulative.legend()
    
def plot_lda(X, y, title, ax):
    lda = LinearDiscriminantAnalysis(n_components=2)
    X_r = lda.fit_transform(X, y)
    
    colors = ['navy', 'turquoise', 'darkorange', 'red', 'green', 'blue', 'purple']
    lw = 2

    unique_classes = np.unique(y)
    for color, i in zip(colors, unique_classes):
        ax.scatter(X_r[y == i, 0], X_r[y == i, 1], alpha=.8, color=color, lw=lw, label=f'Klasa {i}')
    ax.legend(loc='best', shadow=False, scatterpoints=1)
    ax.set_title('LDA z ' + title)

def TM(X, y, lista_modeli, miary, podzial):
    """
    Funkcja zwracająca wyniki miar z walidacji krzyżowej.
    Funkcja przyjmuje:
        X - dane treningowe
        y - etykiety
        lista_moedli - lista modeli
        miary - lista metryk
        podzial - zasady pidziału zbioru treningowego
    """
    wyniki = []
    for nazwa, model in lista_modeli:
        cv_wynik = cross_validate(model, X, y, cv=podzial, scoring=miary, verbose=0, n_jobs=-1, return_train_score=False)

        df = pd.DataFrame(cv_wynik)
        df.insert(0, 'model', nazwa)
        wyniki.append(df)

    final = pd.concat(wyniki, ignore_index=True)
    return final

def TM_rozne_dane(X, y, lista_modeli, miary, podzial, dane=' orginalny'):
    """
    Funkcja zwracająca wyniki miar z walidacji krzyżowej i dodaje do nazwy modelu na jakich danych był trenowny.
    Funkcja przyjmuje:
        X - dane treningowe
        y - etykiety
        lista_moedli - lista modeli
        miary - lista metryk
        podzial - zasady pidziału zbioru treningowego
        dane - nazwa, kóra ma być dodana d nazwy modelu
    """
    wyniki = []
    for nazwa, model in lista_modeli:
        cv_wynik = cross_validate(model, X, y, cv=podzial, scoring=miary, verbose=0, n_jobs=-1, return_train_score=False)

        df = pd.DataFrame(cv_wynik)
        df.insert(0, 'model', nazwa + f'{dane}')
        wyniki.append(df)

    final = pd.concat(wyniki, ignore_index=True)
    return final

def TM_parametry(X, y, lista_modeli, miary, podzial, parametr_testowy=None):
    """
    Funkcja zwracająca wyniki miar z walidacji krzyżowej, z listą parametrów przekazywanych do modeli.
    Funkcja przyjmuje:
        X - dane treningowe
        y - etykiety
        lista_moedli - lista modeli
        miary - lista metryk
        podzial - zasady pidziału zbioru treningowego
        parametr_testowy - parametry przekazywane do modeli
    """
    wyniki = []

    for nazwa, model in lista_modeli:

        if parametr_testowy and isinstance(parametr_testowy, dict):
            for parametr, wartosc in parametr_testowy.items():
                if parametr in model.get_params().keys():
                    model.set_params(**{parametr: wartosc})
                    nazwa = nazwa +f' {wartosc}'
                    print(f'{wartosc} jest dostępne w modelu {model}')
                else:
                    print(f'{wartosc} nie jestdostępne w modelu {model}')
        else:
            print('Parametr_testowy musi być słownikiem')
            break
        cv_wynik = cross_validate(model, X, y, cv=podzial, scoring=miary, n_jobs=-1, verbose=1, return_train_score=False)
        df = pd.DataFrame(cv_wynik)
        df.insert(0, 'model', nazwa)
        wyniki.append(df)

    final = pd.concat(wyniki, ignore_index=True)
    return final


def TM_czas_parametry(X, y, lista_modeli, miary, podzial, parametr_testowy=None):
    start_calkowity = time.time()
    wyniki_czasow = []

    for nazwa, model in lista_modeli:

        if parametr_testowy and isinstance(parametr_testowy, dict):
            for parametr, value in parametr_testowy.items():
                if parametr in model.get_params().keys():
                    model.set_params(**{parametr: value})
            else:
                print('Parametr_testowy musi być słownikiem')
                break
        parametry_str = ", ".join([f"{parametr}: {value}" for parametr, value in parametr_testowy.items()]) if parametr_testowy else "Domyślne"
        

        start_cv = time.time()
        cv_wynik = cross_validate(model, X, y, cv=podzial, scoring=miary, 
                                  n_jobs=parametr_testowy.get('n_jobs', None) if parametr_testowy and 'n_jobs' in parametr_testowy else None, 
                                  verbose=1)
        czas_cv = time.time() - start_cv
        
        wyniki_czasow.append({
            'model': nazwa,
            'czas_cv': czas_cv,
            'parametry': parametry_str
        })
    
    czas_calkowity = time.time() - start_calkowity
    print(f"Całkowity czas wykonania funkcji: {czas_calkowity:.2f} s")
    
    return pd.DataFrame(wyniki_czasow)

def wykres_porownawczy(dane):
    plt.figure(figsize=(10, 6))
    sns.barplot(x='model', y='czas_cv', hue='parametry', data=dane, palette="vlag")
    plt.title('Porównanie czasu walidacji krzyżowej')
    plt.ylabel('Czas (s)')
    plt.xlabel('Model')
    plt.xticks(rotation=45)
    plt.legend(title='Parametry', loc='upper right')
    
    plt.tight_layout()
    plt.show()

def TM_czas_trenowania_walidacjikrzyzowej(X, y, lista_modeli, miary, podzial, nazwa_zbioru, parametr_testowy=None, out_dtype='float64'):
    start_calkowity = time.time()
    wyniki_czasow = []

    for nazwa, model in lista_modeli:
        if parametr_testowy and isinstance(parametr_testowy, dict):
            for parametr, value in parametr_testowy.items():
                if parametr in model.get_params().keys():
                    model.set_params(**{parametr: value})
                    print(f'{wartosc} jest dostępne w modelu {model}')
                else:
                    print(f'{wartosc} nie jestdostępne w modelu {model}')
    for nazwa, model in lista_modeli:
        parametry_str = ", ".join([f"{parametr}: {value}" for parametr, value in parametr_testowy.items()]) if parametr_testowy else "Domyślne"
        
        start_cv = time.time()
        cv_wynik = model_selection.cross_validate(model, X, y, cv=podzial, scoring=miary, n_jobs=parametr_testowy.get('n_jobs', None) if parametr_testowy else None, verbose=1)
        czas_cv = time.time() - start_cv
        
        start_uczenie = time.time()
        model.fit(X, y)
        czas_uczenie = time.time() - start_uczenie
        
        start_zapis = time.time()
        nazwa_pliku = f'{nazwa}_model_{nazwa_zbioru}.pkl'
        joblib.dump(model, nazwa_pliku)
        czas_zapis = time.time() - start_zapis

        wyniki_czasow.append({
            'model': nazwa,
            'czas_cv': czas_cv,
            'czas_uczenie': czas_uczenie,
            'czas_zapis': czas_zapis,
            'parametr_testowy': parametry_str
        })
    
    czas_calkowity = time.time() - start_calkowity
    print(f"Całkowity czas wykonania funkcji: {czas_calkowity:.2f} s")
    
    return pd.DataFrame(wyniki_czasow)

def wykres_porownawczy_walidacia_trenowanie(dane):
    plt.figure(figsize=(20, 6))
    
    plt.subplot(1, 2, 1)
    sns.barplot(x='model', y='czas_cv', hue='parametr_testowy', data=dane, errorbar=None)
    plt.title('Porównanie czasu walidacji krzyżowej')
    plt.ylabel('Czas (s)')
    plt.xlabel('Model')
    plt.xticks(rotation=45)
    plt.legend(title='Testowany parametr')

    plt.subplot(1, 2, 2)
    sns.barplot(x='model', y='czas_uczenie', hue='parametr_testowy', data=dane, errorbar=None)
    plt.title('Porównanie czasu uczenia')
    plt.ylabel('Czas (s)')
    plt.xlabel('Model')
    plt.xticks(rotation=45)
    plt.legend(title='Testowany parametr')
    
    plt.tight_layout()
    plt.show()

def macierz_pomylek(X, y, lista_modeli, podzial):
    """
    Funkcja wyświetlająca macierz pomyłek, z procesu validacji krzyżowej.
    Funkcja przyjmuje:
        X - zbiór treningowy
        y - etykiety
        lista_modeli - lista modeli (nazwa i model)
        podzial - zasady podziału walidacji krzyżowej
    """
    liczba_modeli = len(lista_modeli)
    liczba_kolumn = 3
    liczba_wierszy = np.ceil(liczba_modeli / liczba_kolumn).astype(int)
    fig, axs = plt.subplots(liczba_wierszy, liczba_kolumn, figsize=(liczba_kolumn * 6, liczba_wierszy * 5), squeeze=False)

    for i, (nazwa_modelu, model) in enumerate(lista_modeli):
        row = i // liczba_kolumn
        col = i % liczba_kolumn
        y_pred = cross_val_predict(model, X, y, cv=podzial, n_jobs=-1)
        conf_mat = confusion_matrix(y, y_pred)
        sns.heatmap(conf_mat, annot=True, fmt=".0f", cmap='Blues', ax=axs[row, col])
        axs[row, col].set_title(f'Średnia macierz pomyłek: {nazwa_modelu}')
        axs[row, col].set_xlabel('Predykcja')
        axs[row, col].set_ylabel('Rzeczywiste klasy')
    
    for unused_ax in range(i + 1, liczba_wierszy * liczba_kolumn):
        fig.delaxes(axs.flatten()[unused_ax])

    plt.tight_layout()
    plt.show()

def macierz_pomyłek_proc(X, y, lista_modeli, podzial):
    """
    Funkcja wyświetlająca macierz pomyłek w postaci procentowej, z procesu validacji krzyżowej.
    Funkcja przyjmuje:
        X - zbiór treningowy
        y - etykiety
        lista_modeli - lista modeli (nazwa i model)
        podzial - zasady podziału walidacji krzyżowej
    """
    liczba_modeli = len(lista_modeli)
    liczba_kolumn = 3
    liczba_wierszy = np.ceil(liczba_modeli / liczba_kolumn).astype(int)
    fig, axs = plt.subplots(liczba_wierszy, liczba_kolumn, figsize=(liczba_kolumn * 6, liczba_wierszy * 5), squeeze=False)

    for i, (nazwa_modelu, model) in enumerate(lista_modeli):
        row = i // liczba_kolumn
        col = i % liczba_kolumn

        y_pred = cross_val_predict(model, X, y, cv=podzial, n_jobs=-1)
        conf_mat = confusion_matrix(y, y_pred)
        conf_mat_normalized = conf_mat.astype('float') / conf_mat.sum(axis=1)[:, np.newaxis]
        sns.heatmap(conf_mat_normalized, annot=True, fmt=".2f", cmap='Blues', ax=axs[row, col])
        axs[row, col].set_title(f'Średnia macierz pomyłek: {nazwa_modelu}')
        axs[row, col].set_xlabel('Predykowane klasy')
        axs[row, col].set_ylabel('Rzeczywiste klasy')
    
    for unused_ax in range(i + 1, liczba_wierszy * liczba_kolumn):
        fig.delaxes(axs.flatten()[unused_ax])

    plt.tight_layout()
    plt.show()

def wykresy_boxplot_miary(df, wybrane_metryki, rotation=45, labelsize=10, szerokosc=10):
    """
    Funkcja wyświetla Boxplot z wyników walidacji krzyżowej. Dodatkowo wyrysowuje pionowe linie grupując wyniki o tym samym końcowym słowkie. 
    Funkcja przyjmuje:
        df - dataframe z wynikiami cross_val
        wybrane metryki - lista interesujących nas metryk
    """
    liczba_metryk = len(wybrane_metryki)
    liczba_kolumn = max(1, min(3, liczba_metryk))
    liczba_wierszy = np.ceil(liczba_metryk / liczba_kolumn).astype(int)
    fig, axs = plt.subplots(liczba_wierszy, liczba_kolumn, figsize=(liczba_kolumn * szerokosc, liczba_wierszy * 5), squeeze=False)
    
    dostepne_metryki = [col for col in df.columns if col.startswith('test_')]
    poprawne_metryki = ['test_' + metryka if 'test_' + metryka in dostepne_metryki else metryka for metryka in wybrane_metryki]

    for i, metryka in enumerate(poprawne_metryki):

        row = i // liczba_kolumn
        col = i % liczba_kolumn
        axs[row, col].set_title(metryka.replace('test_', '').replace('_', ' ').title())
        sns.boxplot(x='model', y=metryka, data=df, ax=axs[row, col], palette="Set3")
        axs[row, col].set_xlabel('')
        axs[row, col].set_ylabel('Wynik')
        axs[row, col].tick_params(axis='x', rotation=rotation, labelsize=labelsize)

        
        modele = df['model'].unique()
        #modele_sorted = sorted(modele, key=lambda x: x.split(' ')[-1])
        modele_sorted=modele
        zmiana_zestawu = [i for i, model in enumerate(modele_sorted[:-1]) if modele_sorted[i].split(' ')[-1] != modele_sorted[i+1].split(' ')[-1]]
        for miejsce in zmiana_zestawu:
            axs[row, col].axvline(x=miejsce + 0.5, color='black', linestyle='--')

    for unused_ax in range(i + 1, liczba_wierszy * liczba_kolumn):
        fig.delaxes(axs.flatten()[unused_ax])
        
    plt.tight_layout()
    plt.show()


def plot_multiclass_roc_cv(X, y, lista_modeli, podzial, classes=None):
    """
    Funkcja wyrysowywuje wykresy ROC z procesu walidacji krzyżowej OvR dla podanej listy modeli i listy iteresujących nas klas 
    Funkcja przyjmuje:
        X - dane treningowego
        y - etykiety
        lista_modeli - lista modeli
        podial - zasady podziału zbioru treningowego (bez podania dzieli na 3 foldów)
        classes -  lista interesujących klas (bez podania wyświetla wszystkie)
    """
    liczba_metryk = len(lista_modeli)
    liczba_kolumn = 3
    liczba_wierszy = np.ceil(liczba_metryk / liczba_kolumn).astype(int)
    fig, axs = plt.subplots(liczba_wierszy, liczba_kolumn, figsize=(liczba_kolumn * 6, liczba_wierszy * 5), squeeze=False)


    if classes is None:
        classes = np.unique(y)
    
    y_bin = label_binarize(y, classes=classes)
    n_classes = y_bin.shape[1]

    for i, (nazwa_modelu, model) in enumerate(lista_modeli):
        row = i // liczba_kolumn
        col = i % liczba_kolumn
        ax = axs[row, col]
        ax.set_title(f'ROC Curves for {nazwa_modelu}')
        
        for j in range(n_classes):
            tprs = []
            aucs = []
            mean_fpr = np.linspace(0, 1, 100)
            
            for treningowe, testowe in podzial.split(X, y):
                model.fit(X.iloc[treningowe], y.iloc[treningowe])
                y_score = model.predict_proba(X.iloc[testowe])
                
                if n_classes == 2:
                    fpr, tpr, _ = roc_curve(y_bin[testowe, j], y_score[:, 1])
                else:
                    fpr, tpr, _ = roc_curve(y_bin[testowe, j], y_score[:, j])
                interp_tpr = np.interp(mean_fpr, fpr, tpr)
                interp_tpr[0] = 0.0
                tprs.append(interp_tpr)
                aucs.append(auc(fpr, tpr))
            
            mean_tpr = np.mean(tprs, axis=0)
            mean_tpr[-1] = 1.0
            mean_auc = auc(mean_fpr, mean_tpr)
            std_auc = np.std(aucs)

            ax.plot(mean_fpr, mean_tpr, lw=2, label=f'Class {classes[j]} (AUC = {mean_auc:.2f} $\pm$ {std_auc:.2f})')
        
        ax.plot([0, 1], [0, 1], 'k--', lw=2)
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        ax.legend(loc="lower right")

    for unused_ax in range(i + 1, liczba_wierszy * liczba_kolumn):
        fig.delaxes(axs.flatten()[unused_ax])
    
    plt.tight_layout()
    plt.show()